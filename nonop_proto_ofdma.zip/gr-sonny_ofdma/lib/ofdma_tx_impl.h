/* -*- c++ -*- */
/*
 * Copyright 2022 sonny.
 *
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

#ifndef INCLUDED_SONNY_OFDMA_OFDMA_TX_IMPL_H
#define INCLUDED_SONNY_OFDMA_OFDMA_TX_IMPL_H

#include <sonny_ofdma/ofdma_tx.h>

namespace gr {
  namespace sonny_ofdma {

    class ofdma_tx_impl : public ofdma_tx
    {
     private:
    	//! FFT length
    	const int d_fft_len;
    	//! Which carriers/symbols carry data
    	std::vector<std::vector<int>> d_occupied_carriers;
    	//! Which carriers/symbols carry pilots symbols
    	std::vector<std::vector<int>> d_pilot_carriers;
    	//! Value of said pilot symbols
    	const std::vector<std::vector<gr_complex>> d_pilot_symbols;
    	//! Synch words
    	const std::vector<std::vector<gr_complex>> d_sync_words;
    	int d_symbols_per_set;
    	const bool d_output_is_shifted;
    	pmt::pmt_t d_sc_tag_key; //added here

     protected:
      int calculate_output_stream_length(const gr_vector_int &ninput_items) override;

     public:
      ofdma_tx_impl(
      int fft_len,
      const std::vector<std::vector<int>>& occupied_carriers,
      const std::vector<std::vector<int>>& pilot_carriers,
      const std::vector<std::vector<gr_complex>>& pilot_symbols,
      const std::vector<std::vector<gr_complex>>& sync_words,
      const std::string& len_tag_key,
      const bool output_is_shifted,
      const std::string& sc_tag_key);
      ~ofdma_tx_impl() override;

    std::string len_tag_key() override { return d_length_tag_key_str; };

    const int fft_len() override { return d_fft_len; };
    std::vector<std::vector<int>> occupied_carriers() override
    {
        return d_occupied_carriers;
    };

    int work(int noutput_items,
             gr_vector_int& ninput_items,
             gr_vector_const_void_star& input_items,
             gr_vector_void_star& output_items) override;
};

  } // namespace sonny_ofdma
} // namespace gr

#endif /* INCLUDED_SONNY_OFDMA_OFDMA_TX_IMPL_H */
