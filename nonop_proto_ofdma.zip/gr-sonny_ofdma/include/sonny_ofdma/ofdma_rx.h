/* -*- c++ -*- */
/*
 * Copyright 2022 sonny.
 *
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

#ifndef INCLUDED_SONNY_OFDMA_OFDMA_RX_H
#define INCLUDED_SONNY_OFDMA_OFDMA_RX_H

#include <sonny_ofdma/api.h>
#include <gnuradio/tagged_stream_block.h>

namespace gr {
  namespace sonny_ofdma {
  
    class SONNY_OFDMA_API ofdma_rx : virtual public gr::tagged_stream_block
    {
     public:
      typedef std::shared_ptr<ofdma_rx> sptr;
      
      static sptr make(int fft_len, const std::vector<std::vector<int>>& occupied_carriers, const std::string& len_tag_key = "frame_len", const std::string& packet_len_tag_key = "", int symbols_skipped = 0, const std::string& carr_offset_key = "", bool input_is_shifted = true, const std::string& sc_tag_key = "sc_tag_key");
    };
    
    /*static sptr make(const gr::sonny_ofdma::ofdma_tx::sptr& allocator, const std::string& packet_len_tag_key = "", int symbols_skipped = 0, const std::string& carr_offset_key = "", bool input_is_shifted = true, const std::string& sc_tag_key = "sc_tag_key");*/

  } // namespace sonny_ofdma
} // namespace gr

#endif /* INCLUDED_SONNY_OFDMA_OFDMA_RX_H */
