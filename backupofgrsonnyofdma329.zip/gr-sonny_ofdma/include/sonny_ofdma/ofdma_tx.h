/* -*- c++ -*- */
/*
 * Copyright 2022 sonny.
 *
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

#ifndef INCLUDED_SONNY_OFDMA_OFDMA_TX_H
#define INCLUDED_SONNY_OFDMA_OFDMA_TX_H

#include <sonny_ofdma/api.h>
#include <gnuradio/tagged_stream_block.h>

namespace gr {
  namespace sonny_ofdma {

    class SONNY_OFDMA_API ofdma_tx : virtual public gr::tagged_stream_block
    {
     public:
      typedef std::shared_ptr<ofdma_tx> sptr;
      
      virtual std::string len_tag_key() = 0;
      virtual const int fft_len() = 0;
      virtual std::vector<std::vector<int>> occupied_carriers() = 0;

      static sptr make(int fft_length,
      			const std::vector<std::vector<int>>& occupied_carriers,
                     	const std::vector<std::vector<int>>& pilot_carriers,
                     	const std::vector<std::vector<gr_complex>>& pilot_symbols,
                     	const std::vector<std::vector<gr_complex>>& sync_words,
                     	const std::string& len_tag_key = "packet_len",
                     	const bool output_is_shifted = true,
                     	const std::string& sc_tag_key = "sc_cont");
    };

  } // namespace sonny_ofdma
} // namespace gr

#endif /* INCLUDED_SONNY_OFDMA_OFDMA_TX_H */
