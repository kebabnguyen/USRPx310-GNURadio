/* -*- c++ -*- */
/*
 * Copyright 2022 sonny.
 *
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

#ifndef INCLUDED_SONNY_OFDMA_OFDMA_RX_IMPL_H
#define INCLUDED_SONNY_OFDMA_OFDMA_RX_IMPL_H

#include <sonny_ofdma/ofdma_rx.h>

namespace gr {
  namespace sonny_ofdma {

    class ofdma_rx_impl : public ofdma_rx
    {
     private:
      int d_fft_len;
      std::vector<std::vector<int>>d_occupied_carriers;
      pmt::pmt_t d_packet_len_tag_key;
      pmt::pmt_t d_out_len_tag_key;
      const int d_symbols_skipped;
      pmt::pmt_t d_carr_offset_key;
      int d_curr_set;
      int d_symbols_per_set;
      pmt::pmt_t d_sc_tag_key;
      
     protected:
      int calculate_output_stream_length(const gr_vector_int &ninput_items);
      void update_length_tags(int n_produced, int n_ports) override;
      
     public:
      ofdma_rx_impl(int fft_len, const std::vector<std::vector<int>>& occupied_carriers, const std::string& len_tag_key, const std::string& packet_len_tag_key, int symbols_skipped, const std::string& carr_offset_key, bool input_is_shifted, const std::string& sc_tag_key);
      ~ofdma_rx_impl() override;

      // Where all the action really happens
      int work(
              int noutput_items,
              gr_vector_int &ninput_items,
              gr_vector_const_void_star &input_items,
              gr_vector_void_star &output_items
      ) override;
    };

  } // namespace sonny_ofdma
} // namespace gr

#endif /* INCLUDED_SONNY_OFDMA_OFDMA_RX_IMPL_H */
