/* -*- c++ -*- */
/*
 * Copyright 2022 kevan ig.
 *
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

#include <gnuradio/io_signature.h>
#include "togglewrite_filesink_impl.h"
#include <stdio.h>

namespace gr {
  namespace customblocka {

    using input_type = char;
    using output_type = char; 
    togglewrite_filesink::sptr
    togglewrite_filesink::make(size_t itemsize, const char* filename, bool append)
    {
      return gnuradio::make_block_sptr<togglewrite_filesink_impl>(
        itemsize, filename, append);
    }


    /*
     * The private constructor
     */
    togglewrite_filesink_impl::togglewrite_filesink_impl(size_t itemsize, const char* filename, bool append)
      : gr::sync_block("togglewrite_filesink",
              gr::io_signature::make(1, 1, itemsize),
              gr::io_signature::make(0,0,0)), file_sink_base(filename, true, append), d_itemsize(itemsize)
    {
    	selfilename = filename;
    	message_port_register_in(pmt::mp("reset"));
    	set_msg_handler(pmt::mp("reset"), [this] (const pmt::pmt_t& msg) {this->reset(msg);});
    }

    /*
     * Our virtual destructor.
     */
    togglewrite_filesink_impl::~togglewrite_filesink_impl()
    {
    }

    void togglewrite_filesink_impl::reset(const pmt::pmt_t& msg)
    {
    //we just to rewrite to the file if we get a true message
    	if(pmt::is_bool(msg))
    	{
    	   d_updated = pmt::to_bool(msg);
    	   
    	   close();
    	   d_new_fp = fopen("bababooey.bin", "wb");
    	   do_update();
    	}
    	
    }

    void
    togglewrite_filesink_impl::forecast (int noutput_items, gr_vector_int &ninput_items_required)
    {
    //#pragma message("implement a forecast that fills in how many items on each input you need to produce noutput_items and remove this warning")
      /* <+forecast+> e.g. ninput_items_required[0] = noutput_items */
    }

    int
    togglewrite_filesink_impl::work (int noutput_items,
                       gr_vector_const_void_star &input_items,
                       gr_vector_void_star &output_items)
    {
    const char* inbuf = static_cast<const char*>(input_items[0]);
    int nwritten = 0;

    do_update(); // update d_fp is reqd

    if (!d_fp)
        return noutput_items; // drop output on the floor

    while (nwritten < noutput_items) {
        const int count = fwrite(inbuf, d_itemsize, noutput_items - nwritten, d_fp);
        if (count == 0) {
            if (ferror(d_fp)) {
                std::stringstream s;
                s << "file_sink write failed with error " << fileno(d_fp) << std::endl;
                throw std::runtime_error(s.str());
            } else { // is EOF
                break;
            }
        }
        nwritten += count;
        inbuf += count * d_itemsize;
    }

    if (d_unbuffered)
        fflush(d_fp);

    return nwritten;
}

    bool togglewrite_filesink_impl::stop()
{
    do_update();
    fflush(d_fp);
    return true;
}

  } /* namespace customblocka */
} /* namespace gr */
