/* -*- c++ -*- */
/*
 * Copyright 2022 kevan ig.
 *
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

#ifndef INCLUDED_CUSTOMBLOCKA_TOGGLEWRITE_FILESINK_IMPL_H
#define INCLUDED_CUSTOMBLOCKA_TOGGLEWRITE_FILESINK_IMPL_H

#include <gnuradio/customblocka/togglewrite_filesink.h>

namespace gr {
  namespace customblocka {

    class togglewrite_filesink_impl : public togglewrite_filesink
    {
     private:
      const size_t d_itemsize;
      void reset(const pmt::pmt_t& msg);
      const char* selfilename;

     public:
      togglewrite_filesink_impl(size_t itemsize, const char* filename, bool append = false);
      ~togglewrite_filesink_impl() override;

      // Where all the action really happens
      void forecast (int noutput_items, gr_vector_int &ninput_items_required);

      int work(int noutput_items,
           gr_vector_const_void_star &input_items,
           gr_vector_void_star &output_items);

      bool stop() override;

    };

  } // namespace customblocka
} // namespace gr

#endif /* INCLUDED_CUSTOMBLOCKA_TOGGLEWRITE_FILESINK_IMPL_H */
