/* -*- c++ -*- */
/*
 * Copyright 2022 kevan ig.
 *
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

#ifndef INCLUDED_CUSTOMBLOCKA_TOGGLEWRITE_FILESINK_H
#define INCLUDED_CUSTOMBLOCKA_TOGGLEWRITE_FILESINK_H

#include <gnuradio/customblocka/api.h>
#include <gnuradio/sync_block.h>
#include <gnuradio/blocks/file_sink_base.h>

namespace gr {
  namespace customblocka {

    /*!
     * \brief <+description of block+>
     * \ingroup customblocka
     *
     */
    class CUSTOMBLOCKA_API togglewrite_filesink : virtual public gr::sync_block, virtual public blocks::file_sink_base
    {
     public:
      typedef std::shared_ptr<togglewrite_filesink> sptr;

      /*!
       * \brief Return a shared_ptr to a new instance of customblocka::togglewrite_filesink.
       *
       * To avoid accidental use of raw pointers, customblocka::togglewrite_filesink's
       * constructor is in a private implementation
       * class. customblocka::togglewrite_filesink::make is the public interface for
       * creating new instances.
       */
      static sptr make(size_t itemsize, const char* filename, bool append = false);
    };

  } // namespace customblocka
} // namespace gr

#endif /* INCLUDED_CUSTOMBLOCKA_TOGGLEWRITE_FILESINK_H */
