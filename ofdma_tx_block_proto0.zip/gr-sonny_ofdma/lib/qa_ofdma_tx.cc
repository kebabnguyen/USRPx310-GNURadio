/* -*- c++ -*- */
/*
 * Copyright 2022 sonny.
 *
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

#include <sonny_ofdma/ofdma_tx.h>
#include <gnuradio/attributes.h>
#include <boost/test/unit_test.hpp>

namespace gr {
  namespace sonny_ofdma {

    BOOST_AUTO_TEST_CASE(test_ofdma_tx_replace_with_specific_test_name)
    {
      // Put test here
    }

  } /* namespace sonny_ofdma */
} /* namespace gr */
